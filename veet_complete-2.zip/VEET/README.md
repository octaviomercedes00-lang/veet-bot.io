# VEET - Discord Bot + Admin Panel (Replit-ready)

Este es un paquete con la versión completa del proyecto VEET:
- Bot de Discord (Node.js + discord.js v14)
- Panel de administración (Express + EJS + Passport Discord OAuth2)
- Rutas públicas y assets (views/, public/)
- Ejemplos de comandos y eventos

**IMPORTANTE**: No incluyas tus secretos en archivos comprometidos. Usa `.env` o los Secrets de Replit.

## Para ejecutar en Replit (o local)
1. Copia `.env.example` a `.env` y rellena valores, o añade las variables en Replit Secrets:
   - TOKEN
   - CLIENT_ID
   - CLIENT_SECRET
   - REDIRECT_URI
   - SESSION_SECRET
2. Ejecuta:
   ```
   npm install
   npm start
   ```
3. Abre la URL que Replit te da (ej. https://tuusuario.repl.co)
