console.log('VEET panel scripts loaded');
