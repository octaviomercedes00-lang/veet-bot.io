module.exports = {
  name: 'help',
  description: 'Muestra comandos disponibles',
  async execute(message) {
    message.reply('Comandos disponibles: !ping, !help');
  }
};
