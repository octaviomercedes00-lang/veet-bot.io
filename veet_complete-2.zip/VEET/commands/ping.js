module.exports = {
  name: 'ping',
  description: 'Responde con la latencia del bot',
  async execute(message) {
    message.reply(`🏓 Pong! Latencia: ${Date.now() - message.createdTimestamp}ms`);
  }
};
