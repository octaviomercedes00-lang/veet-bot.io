require('dotenv').config();
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const keepAlive = require('./keep_alive');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.commands = new Collection();

// Load commands
const commandFiles = fs.existsSync('./commands') ? fs.readdirSync('./commands').filter(f => f.endsWith('.js')) : [];
for (const file of commandFiles) {
  const cmd = require(path.join(__dirname, 'commands', file));
  if (cmd && cmd.name) client.commands.set(cmd.name, cmd);
}

client.on('messageCreate', async (msg) => {
  if (!msg.content.startsWith('!') || msg.author.bot) return;
  const args = msg.content.slice(1).trim().split(/ +/);
  const command = args.shift().toLowerCase();
  const cmd = client.commands.get(command);
  if (cmd && typeof cmd.execute === 'function') {
    try {
      await cmd.execute(msg, args, client);
    } catch (err) {
      console.error('Command error:', err);
      msg.reply('❌ Ocurrió un error ejecutando ese comando.');
    }
  }
});

// Load events
const eventsPath = './events';
if (fs.existsSync(eventsPath)) {
  const eventFiles = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));
  for (const file of eventFiles) {
    const event = require(path.join(__dirname, 'events', file));
    if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
    else client.on(event.name, (...args) => event.execute(...args, client));
  }
}

keepAlive();
client.login(process.env.TOKEN).catch(err => console.error('Login error:', err));
