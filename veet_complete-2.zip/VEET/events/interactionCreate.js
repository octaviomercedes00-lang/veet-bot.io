module.exports = {
  name: 'interactionCreate',
  execute(interaction) {
    // placeholder for slash commands or interactions
    if (!interaction.isCommand()) return;
    // handle commands if registered
  }
};
