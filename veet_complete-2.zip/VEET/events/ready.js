module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`[✅] ${client.user.tag} está listo.`);
    client.user.setActivity('✨ VEET Panel', { type: 0 });
  }
};
